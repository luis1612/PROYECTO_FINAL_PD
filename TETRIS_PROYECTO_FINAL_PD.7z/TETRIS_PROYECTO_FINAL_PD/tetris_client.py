# Tetromino (un clon de Tetris)

# }}}}+

# Lanzado bajo una licencia "BSD simplificado"


'''
hacer que el tetris valga más
hacer el mismo bloque siempre del mismo color
agregar un búfer

###puntaje po lineas###
1 línea = 40 pts
2 líneas = 100
3 líneas = 300
tetris = 1200

multiplicador por nivel

'''

import random, time, pygame, sys, socket, time
from pygame.locals import *

FPS = 25
WINDOWWIDTH = 640
WINDOWHEIGHT = 480
BOXSIZE = 20
BOARDWIDTH = 10
BOARDHEIGHT = 20
BLANK = '.'

MOVESIDEWAYSFREQ = 0.15
MOVEDOWNFREQ = 0.1

XMARGIN = int((WINDOWWIDTH - BOARDWIDTH * BOXSIZE) / 2)
TOPMARGIN = WINDOWHEIGHT - (BOARDHEIGHT * BOXSIZE) - 5

#               R    G    B
WHITE       = (255, 255, 255)
GRAY        = (185, 185, 185)
BLACK       = (  0,   0,   0)
RED         = (155,   0,   0)
LIGHTRED    = (175,  20,  20)
GREEN       = (  0, 155,   0)
LIGHTGREEN  = ( 20, 175,  20)
BLUE        = (  0,   0, 155)
LIGHTBLUE   = ( 20,  20, 175)
YELLOW      = (155, 155,   0)
LIGHTYELLOW = (175, 175,  20)

BORDERCOLOR = BLUE
BGCOLOR = BLACK
TEXTCOLOR = WHITE
TEXTSHADOWCOLOR = GRAY
COLORS      = (     BLUE,      GREEN,      RED,      YELLOW)
LIGHTCOLORS = (LIGHTBLUE, LIGHTGREEN, LIGHTRED, LIGHTYELLOW)
assert len(COLORS) == len(LIGHTCOLORS) # cada color debe tener color claro

TEMPLATEWIDTH = 5
TEMPLATEHEIGHT = 5

S_SHAPE_TEMPLATE = [['.....',
					 '.....',
					 '..OO.',
					 '.OO..',
					 '.....'],
					['.....',
					 '..O..',
					 '..OO.',
					 '...O.',
					 '.....']]

Z_SHAPE_TEMPLATE = [['.....',
					 '.....',
					 '.OO..',
					 '..OO.',
					 '.....'],
					['.....',
					 '..O..',
					 '.OO..',
					 '.O...',
					 '.....']]

I_SHAPE_TEMPLATE = [['..O..',
					 '..O..',
					 '..O..',
					 '..O..',
					 '.....'],
					['.....',
					 '.....',
					 'OOOO.',
					 '.....',
					 '.....']]

O_SHAPE_TEMPLATE = [['.....',
					 '.....',
					 '.OO..',
					 '.OO..',
					 '.....']]

J_SHAPE_TEMPLATE = [['.....',
					 '.O...',
					 '.OOO.',
					 '.....',
					 '.....'],
					['.....',
					 '..OO.',
					 '..O..',
					 '..O..',
					 '.....'],
					['.....',
					 '.....',
					 '.OOO.',
					 '...O.',
					 '.....'],
					['.....',
					 '..O..',
					 '..O..',
					 '.OO..',
					 '.....']]

L_SHAPE_TEMPLATE = [['.....',
					 '...O.',
					 '.OOO.',
					 '.....',
					 '.....'],
					['.....',
					 '..O..',
					 '..O..',
					 '..OO.',
					 '.....'],
					['.....',
					 '.....',
					 '.OOO.',
					 '.O...',
					 '.....'],
					['.....',
					 '.OO..',
					 '..O..',
					 '..O..',
					 '.....']]

T_SHAPE_TEMPLATE = [['.....',
					 '..O..',
					 '.OOO.',
					 '.....',
					 '.....'],
					['.....',
					 '..O..',
					 '..OO.',
					 '..O..',
					 '.....'],
					['.....',
					 '.....',
					 '.OOO.',
					 '..O..',
					 '.....'],
					['.....',
					 '..O..',
					 '.OO..',
					 '..O..',
					 '.....']]

PIECES = {'S': S_SHAPE_TEMPLATE,
		  'Z': Z_SHAPE_TEMPLATE,
		  'J': J_SHAPE_TEMPLATE,
		  'L': L_SHAPE_TEMPLATE,
		  'I': I_SHAPE_TEMPLATE,
		  'O': O_SHAPE_TEMPLATE,
		  'T': T_SHAPE_TEMPLATE}



HOST = '127.0.0.1'  # El nombre de host o la dirección IP del servidor
PORT = 65432        # El puerto utilizado por el servidor.

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
print('conectado al servidor')

def main():
	global FPSCLOCK, DISPLAYSURF, BASICFONT, BIGFONT
	pygame.init()
	FPSCLOCK = pygame.time.Clock()
	DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
	BASICFONT = pygame.font.Font('freesansbold.ttf', 18)
	BIGFONT = pygame.font.Font('freesansbold.ttf', 100)
	pygame.display.set_caption('2-J Tetris')

	showTextScreen('2-J Tetris')

	while True: # juego bucle

		s.send("['ready','listo']".encode('utf-8'))
		print('enviando listo al servidor')
		time.sleep(6)
		# bloquear mientras se espera la señal de inicio del juego desde el servidor
		strt = str(s.recv(1024).decode())

		print('Corriendo el juego')
		runGame()
		showTextScreen('Juego terminado')


def runGame():
	# variables de configuración para el inicio del juego
	board = getBlankBoard()
	lastMoveDownTime = time.time()
	lastMoveSidewaysTime = time.time()
	lastFallTime = time.time()
	movingDown = False # nota: no hay ninguna variable ascendente
	movingLeft = False
	movingRight = False
	score = 0
	pts = 0
	pts2 = 0
	level, fallFreq = calculateLevelAndFallFreq(score)

	fallingPiece = getNewPiece()
	nextPiece = getNewPiece()

	# juego bucle
	try:
		mensaje = "['puntos','%s']" % str(pts)
		s.send(mensaje.encode('utf-8'))
	except ValueError as e:
		print(e)
		pass
	while True:
		if fallingPiece == None:
			# Ninguna pieza que cae en juego, así que comienza una nueva pieza en la parte superior
			fallingPiece = nextPiece
			nextPiece = getNewPiece()
			lastFallTime = time.time() # restablecer el último tiempo de caída

			if not isValidPosition(board, fallingPiece):
				try:
					mensaje = "['fin_juego','perdi']"
					s.send(mensaje.encode("utf-8"))
					return
				except:
					pass
				return # no se puede colocar una nueva pieza en el tablero, así que el juego termina

		checkForQuit()
		for event in pygame.event.get(): # bucle de manejo de eventos
			if event.type == KEYUP:
				if (event.key == K_p):
					# Pausando el juego
					DISPLAYSURF.fill(BGCOLOR)
					#pygame.mixer.music.stop()
					showTextScreen('En pausa') # pausa hasta que se presione una tecla
					#pygame.mixer.music.play(-1, 0.0)
					lastFallTime = time.time()
					lastMoveDownTime = time.time()
					lastMoveSidewaysTime = time.time()
				elif (event.key == K_LEFT or event.key == K_a):
					movingLeft = False
				elif (event.key == K_RIGHT or event.key == K_d):
					movingRight = False
				elif (event.key == K_DOWN or event.key == K_s):
					movingDown = False

			elif event.type == KEYDOWN:
				# moviendo la pieza de lado
				if (event.key == K_LEFT or event.key == K_a) and isValidPosition(board, fallingPiece, adjX=-1):
					fallingPiece['x'] -= 1
					movingLeft = True
					movingRight = False
					lastMoveSidewaysTime = time.time()

				elif (event.key == K_RIGHT or event.key == K_d) and isValidPosition(board, fallingPiece, adjX=1):
					fallingPiece['x'] += 1
					movingRight = True
					movingLeft = False
					lastMoveSidewaysTime = time.time()

				# girando la pieza (si hay espacio para rotar)
				elif (event.key == K_UP or event.key == K_w):
					fallingPiece['rotation'] = (fallingPiece['rotation'] + 1) % len(PIECES[fallingPiece['shape']])
					if not isValidPosition(board, fallingPiece):
						fallingPiece['rotation'] = (fallingPiece['rotation'] - 1) % len(PIECES[fallingPiece['shape']])
				elif (event.key == K_q): # girar la otra dirección
					fallingPiece['rotation'] = (fallingPiece['rotation'] - 1) % len(PIECES[fallingPiece['shape']])
					if not isValidPosition(board, fallingPiece):
						fallingPiece['rotation'] = (fallingPiece['rotation'] + 1) % len(PIECES[fallingPiece['shape']])

				# haciendo que la pieza caiga más rápido con la tecla de abajo
				elif (event.key == K_DOWN or event.key == K_s):
					movingDown = True
					if isValidPosition(board, fallingPiece, adjY=1):
						fallingPiece['y'] += 1
					lastMoveDownTime = time.time()

				# mover la pieza actual completamente hacia abajo
				elif event.key == K_SPACE:
					movingDown = False
					movingLeft = False
					movingRight = False
					for i in range(1, BOARDHEIGHT):
						if not isValidPosition(board, fallingPiece, adjY=i):
							break
					fallingPiece['y'] += i - 1

		# manejar mover la pieza debido a la entrada del usuario
		if (movingLeft or movingRight) and time.time() - lastMoveSidewaysTime > MOVESIDEWAYSFREQ:
			if movingLeft and isValidPosition(board, fallingPiece, adjX=-1):
				fallingPiece['x'] -= 1
			elif movingRight and isValidPosition(board, fallingPiece, adjX=1):
				fallingPiece['x'] += 1
			lastMoveSidewaysTime = time.time()

		if movingDown and time.time() - lastMoveDownTime > MOVEDOWNFREQ and isValidPosition(board, fallingPiece, adjY=1):
			fallingPiece['y'] += 1
			lastMoveDownTime = time.time()

		# deja caer la pieza si es el momento de caer
		if time.time() - lastFallTime > fallFreq:
			# see if the piece has landed
			if not isValidPosition(board, fallingPiece, adjY=1):
				# la pieza que cae ha aterrizado, ponla en el tablero
				addToBoard(board, fallingPiece)
				lines = removeCompleteLines(board) #numero lineas despejadas este turno
				# puntaje es el total de líneas eliminadas en este juego, que se usa para calcular el nivel
				score += lines 
				# obtener la puntuación para el turno usando el sistema de puntos
				turn_score = turnScore(lines)
				pts += turn_score               #total de los puntos
				level, fallFreq = calculateLevelAndFallFreq(score)
				fallingPiece = None
			else:
				# la pieza no aterrizó, solo mueve la pieza hacia abajo
				fallingPiece['y'] += 1
				lastFallTime = time.time()

		# enviar la puntuación actual al servidor
		try:
			# recv puntuación del oponente del servidor
			mensaje = eval(str(s.recv(1024).decode()))
			if mensaje[0] == "puntos_oponente":
				pts2 = int(mensaje[1])
				mensaje = "['puntos','%s']" % str(pts)
				s.send(mensaje.encode('utf-8'))
				pass
			elif mensaje[0] == "fin_juego":
				return
		except:
			pass
		# agregar manejo para recv 'salir', 'ganador', 'esc'


		''' dibujando todo en la pantalla  '''
		DISPLAYSURF.fill(BGCOLOR)
		drawBoard(board)
		drawStatus(score, level, pts, pts2)
		drawNextPiece(nextPiece)
		if fallingPiece != None:
			drawPiece(fallingPiece)

		pygame.display.update()
		FPSCLOCK.tick(FPS)

def turnScore(lines):
	# calcula la puntuación en función del número de líneas borradas a la vez
	# más líneas a la vez = más puntos
	if lines == 1:
		turn_score = 40
	elif lines == 2:
		turn_score = 100
	elif lines == 3:
		turn_score = 300
	elif lines == 4: 
		turn_score = 1200
	else:
		turn_score = 0
	return turn_score



def makeTextObjs(text, font, color):
	surf = font.render(text, True, color)
	return surf, surf.get_rect()


def terminate():
	pygame.quit()
	sys.exit()


def checkForKeyPress():
	# Ir a través de la cola de eventos en busca de un evento KEYUP.
	# Agarra los eventos KEYDOWN para eliminarlos de la cola de eventos.
	checkForQuit()

	for event in pygame.event.get([KEYDOWN, KEYUP]):
		if event.type == KEYDOWN:
			continue
		return event.key
	return None


def showTextScreen(text):
	# Esta función muestra texto grande en el
	# centro de la pantalla hasta que se presiona una tecla.
	# Dibujar la sombra de texto
	titleSurf, titleRect = makeTextObjs(text, BIGFONT, TEXTSHADOWCOLOR)
	titleRect.center = (int(WINDOWWIDTH / 2), int(WINDOWHEIGHT / 2))
	DISPLAYSURF.blit(titleSurf, titleRect)

	# Dibujar el texto
	titleSurf, titleRect = makeTextObjs(text, BIGFONT, TEXTCOLOR)
	titleRect.center = (int(WINDOWWIDTH / 2) - 3, int(WINDOWHEIGHT / 2) - 3)
	DISPLAYSURF.blit(titleSurf, titleRect)

	# Dibuja el adicional "Presiona una tecla para jugar". texto.
	pressKeySurf, pressKeyRect = makeTextObjs('Presiona una tecla para jugar.', BASICFONT, TEXTCOLOR)
	pressKeyRect.center = (int(WINDOWWIDTH / 2), int(WINDOWHEIGHT / 2) + 100)
	DISPLAYSURF.blit(pressKeySurf, pressKeyRect)

	while checkForKeyPress() == None:
		pygame.display.update()
		FPSCLOCK.tick()

	# jugador esta listo
	# notificar servidor

	return



def checkForQuit():
	for event in pygame.event.get(QUIT): # obtener todos los eventos QUIT
		#
		# enviar un mensaje al servidor para salir
		#
		try:
			mensaje = "['fin_juego','perdi']"
			s.send(mensaje.encode("utf-8"))
			return
		except:
			pass
		terminate() # terminar si hay algún evento QUIT presente
	for event in pygame.event.get(KEYUP): # obtener todos los eventos KEYUP
		if event.key == K_ESCAPE:
			#
			#
			try:
				mensaje = "['fin_juego','perdi']"
				s.send(mensaje.encode("utf-8"))
				return
			except:
				pass
			#enviar un mensaje al servidor para salir
			terminate() # terminar si el evento KEYUP fue para la tecla Esc
		pygame.event.post(event) # devolver los otros objetos de evento KEYUP


def calculateLevelAndFallFreq(score):
	# Según la puntuación, devuelva el nivel en el que se encuentra el jugador y
	# cuántos segundos pasan hasta que una pieza que cae cae un espacio.
	level = int(score / 10) + 1
	fallFreq = 0.27 - (level * 0.02)
	return level, fallFreq

def getNewPiece():
	# devuelve una nueva pieza aleatoria en una rotación y color aleatorios
	shape = random.choice(list(PIECES.keys()))
	newPiece = {'shape': shape,
				'rotation': random.randint(0, len(PIECES[shape]) - 1),
				'x': int(BOARDWIDTH / 2) - int(TEMPLATEWIDTH / 2),
				'y': -2, # iniciarlo por encima del tablero (es decir, menos de 0)
				'color': random.randint(0, len(COLORS)-1)}
	return newPiece


def addToBoard(board, piece):
	# rellene el tablero basándose en la ubicación, forma y rotación de la pieza
	for x in range(TEMPLATEWIDTH):
		for y in range(TEMPLATEHEIGHT):
			if PIECES[piece['shape']][piece['rotation']][y][x] != BLANK:
				board[x + piece['x']][y + piece['y']] = piece['color']


def getBlankBoard():
	# crear y devolver una nueva estructura de datos de tablero en blanco
	board = []
	for i in range(BOARDWIDTH):
		board.append([BLANK] * BOARDHEIGHT)
	return board


def isOnBoard(x, y):
	return x >= 0 and x < BOARDWIDTH and y < BOARDHEIGHT


def isValidPosition(board, piece, adjX=0, adjY=0):
	# Devuelve True si la pieza está dentro del tablero y no choca.
	for x in range(TEMPLATEWIDTH):
		for y in range(TEMPLATEHEIGHT):
			isAboveBoard = y + piece['y'] + adjY < 0
			if isAboveBoard or PIECES[piece['shape']][piece['rotation']][y][x] == BLANK:
				continue
			if not isOnBoard(x + piece['x'] + adjX, y + piece['y'] + adjY):
				return False
			if board[x + piece['x'] + adjX][y + piece['y'] + adjY] != BLANK:
				return False
	return True

def isCompleteLine(board, y):
	# Devuelva True si la línea se rellena con cuadros sin espacios.
	for x in range(BOARDWIDTH):
		if board[x][y] == BLANK:
			return False
	return True


def removeCompleteLines(board):
	#Elimine las líneas completadas en el tablero, mueva todo lo que está sobre ellas hacia abajo y devuelva el número de líneas completas.
	numLinesRemoved = 0
	y = BOARDHEIGHT - 1 # inicio y en la parte inferior del tablero
	while y >= 0:
		if isCompleteLine(board, y):
			# Retire la línea y tire de las cajas hacia abajo una línea.
			for pullDownY in range(y, 0, -1):
				for x in range(BOARDWIDTH):
					board[x][pullDownY] = board[x][pullDownY-1]
			# Establezca la línea superior en blanco.
			for x in range(BOARDWIDTH):
				board[x][0] = BLANK
			numLinesRemoved += 1
		# Nota en la siguiente iteración del bucle, y es el mismo.
		# Esto es para que si la línea que fue tirada también es
		# Completo, será eliminado.
		else:
			y -= 1 # pasar a revisar la siguiente fila arriba
	return numLinesRemoved


def convertToPixelCoords(boxx, boxy):
	# Convertir las coordenadas xy dadas del tablero a xy
	# coordenadas de la ubicación en la pantalla.
	return (XMARGIN + (boxx * BOXSIZE)), (TOPMARGIN + (boxy * BOXSIZE))


def drawBox(boxx, boxy, color, pixelx=None, pixely=None):
	# dibujar una sola caja (cada pieza de tetromino tiene cuatro cajas)
	# en las coordenadas xy en el tablero. O, si pixelx y pixely
	# están especificados, dibujar en las coordenadas de píxeles almacenadas en
	# pixelx & pixely (esto se usa para la pieza "Siguiente").
	if color == BLANK:
		return
	if pixelx == None and pixely == None:
		pixelx, pixely = convertToPixelCoords(boxx, boxy)
	pygame.draw.rect(DISPLAYSURF, COLORS[color], (pixelx + 1, pixely + 1, BOXSIZE - 1, BOXSIZE - 1))
	pygame.draw.rect(DISPLAYSURF, LIGHTCOLORS[color], (pixelx + 1, pixely + 1, BOXSIZE - 4, BOXSIZE - 4))


def drawBoard(board):
	# dibujar el borde alrededor del tablero
	pygame.draw.rect(DISPLAYSURF, BORDERCOLOR, (XMARGIN - 3, TOPMARGIN - 7, (BOARDWIDTH * BOXSIZE) + 8, (BOARDHEIGHT * BOXSIZE) + 8), 5)

	# Rellena el fondo del tablero.
	pygame.draw.rect(DISPLAYSURF, BGCOLOR, (XMARGIN, TOPMARGIN, BOXSIZE * BOARDWIDTH, BOXSIZE * BOARDHEIGHT))
	# dibujar las cajas individuales en el tablero
	for x in range(BOARDWIDTH):
		for y in range(BOARDHEIGHT):
			drawBox(x, y, board[x][y])


def drawStatus(score, level, points, points2):
	# dibujar el texto de puntuación
	scoreSurf = BASICFONT.render('Líneas: %s' % score, True, TEXTCOLOR)
	scoreRect = scoreSurf.get_rect()
	scoreRect.topleft = (WINDOWWIDTH - 150, 20)
	DISPLAYSURF.blit(scoreSurf, scoreRect)

	# dibujar el texto de nivel
	levelSurf = BASICFONT.render('Nivel: %s' % level, True, TEXTCOLOR)
	levelRect = levelSurf.get_rect()
	levelRect.topleft = (WINDOWWIDTH - 150, 50)
	DISPLAYSURF.blit(levelSurf, levelRect)

	# dibuja el total de puntos de este jugador
	levelSurf = BASICFONT.render('Mi puntaje: %s' % points, True, TEXTCOLOR)
	levelRect = levelSurf.get_rect()
	levelRect.topleft = (20, 20)
	DISPLAYSURF.blit(levelSurf, levelRect)

	# dibujar el total de puntos de los jugadores oponentes
	levelSurf = BASICFONT.render('Puntaje del oponente: %s' % points2, True, TEXTCOLOR)
	levelRect = levelSurf.get_rect()
	levelRect.topleft = (20, 50)
	DISPLAYSURF.blit(levelSurf, levelRect)

def drawPiece(piece, pixelx=None, pixely=None):
	shapeToDraw = PIECES[piece['shape']][piece['rotation']]
	if pixelx == None and pixely == None:
		# Si no se ha especificado pixelx & pixely, use la ubicación almacenada en la estructura de datos de la pieza
		pixelx, pixely = convertToPixelCoords(piece['x'], piece['y'])

	# Dibuja cada una de las cajas que componen la pieza.
	for x in range(TEMPLATEWIDTH):
		for y in range(TEMPLATEHEIGHT):
			if shapeToDraw[y][x] != BLANK:
				drawBox(None, None, piece['color'], pixelx + (x * BOXSIZE), pixely + (y * BOXSIZE))


def drawNextPiece(piece):
	# dibujar el texto "siguiente"
	nextSurf = BASICFONT.render('Next:', True, TEXTCOLOR)
	nextRect = nextSurf.get_rect()
	nextRect.topleft = (WINDOWWIDTH - 120, 110)
	DISPLAYSURF.blit(nextSurf, nextRect)
	# dibujar el texto "siguiente"
	drawPiece(piece, pixelx=WINDOWWIDTH-120, pixely=120)


if __name__ == '__main__':
	main()