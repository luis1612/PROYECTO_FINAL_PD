from socket import *
from time import *
import threading, mysql.connector


class Servidor():
    def __init__(self):

        HOST = '127.0.0.1'
        PORT = 65432

        print('Inciando Servidor...')

        # crear un socket de escucha TCP / IP

        self.s = socket(AF_INET, SOCK_STREAM)
        self.s.bind((HOST, PORT))
        self.s.listen(5)
        print('Escuchando conexiones en el puerto ', PORT)
        try: #se intenta dar la conexión a dos clientes, si hay un error, no va a dañar el servidor.
            hilo_esperando_usuarios  = threading.Thread(target=self.esperando_usuarios, name="esperando_usuarios")
            hilo_esperando_usuarios.start()
            hilo_esperando_usuarios.join()

            print('ambos jugadores conectados')

            sleep(1)

            print('esperando a que los jugadores se preparen ...')

            self.s.setblocking(0)  # permitir que las llamadas de socket devuelvan Ninguna

            # Secuencia lista
            # Una vez que ambos jugadores han confirmado que están listos, el juego comienza

            hilo_inicio_juego = threading.Thread(target=self.hilo_juego,name="hilo_inicio_juego")
            hilo_inicio_juego.start()
        except ValueError as e:
            print(e)
            pass

    def esperando_usuarios(self):
        try:
            while (True):
                try:
                    self.p1, self.a1 = self.s.accept()
                    if self.p1 != None:
                        print('jugador 1 conectado desde el puerto', str(self.a1))
                        break
                except:
                    break

            # encuesta para un segundo jugador

            while (True):
                try:
                    self.p2, self.a2 = self.s.accept()
                    if self.a2 != self.a1:  # Asegúrate de que no sea un socket diferente
                        print('jugador 2 conectado desde el puerto ', str(self.a2))
                        break
                except:
                    break
        except ValueError as e:
            print(e)
            return
    def hilo_juego(self):
        while (True):
            try:
                try:
                    p1_data = str(self.p1.recv(1024).decode())
                    p1_data = eval(p1_data)
                except:
                    pass

                try:
                    p2_data = str(self.p2.recv(1024).decode())
                    p2_data = eval(p2_data)
                except:
                    pass
                try:
                    if p1_data[0] == "ready" and p2_data[0] == "ready":
                        print('jugador 1', p1_data[1])
                        print('jugador 2', p2_data[1])
                        #guardando la partida en la base de datos.
                        try:
                            conexion, cursor = self.conexion_base_datos()
                            sql = 'INSERT INTO juegos (jugador1, jugador2, puntos_jugador1,puntos_jugador2,ganador) VALUES ("%s", "%s", "0", "0", NULL)' % (str(self.a1), str(self.a2))
                            cursor.execute(sql)
                            conexion.commit()
                        except Exception as e:
                            print(e)
                            pass
                        # Enviar señal de inicio del juego a ambos jugadores.
                        self.p2.send(str(p1_data).encode('utf-8'))
                        self.p1.send(str(p2_data).encode('utf-8'))
                        print('Enviando inicio a ambos jugadores')
                    elif p1_data[0] == "puntos" and p2_data[0] == "puntos":
                        #se actualizan los puntos de los jugadores en la base de datos.
                        try:
                            conexion, cursor = self.conexion_base_datos()
                            sql = 'UPDATE juegos SET puntos_jugador1 = "%s", puntos_jugador2 = "%s" WHERE jugador1 = "%s" AND jugador2 = "%s"' % (str(p1_data[1]), str(p2_data[1]), str(self.a1), str(self.a2))
                            cursor.execute(sql)
                            conexion.commit()
                        except Exception as e:
                            print(e)
                            pass
                        # Enviar puntos del contricante a ambos jugadores.
                        mensaje = "['puntos_oponente','%s']" % str(p1_data[1])
                        self.p2.send(mensaje.encode('utf-8'))
                        mensaje = "['puntos_oponente','%s']" % str(p2_data[1])
                        self.p1.send(mensaje.encode('utf-8'))
                    elif p1_data[0] == "fin_juego" or p2_data[0] == "fin_juego":
                        #se actualiza la base de datos, indicando quien gano
                        if p1_data[1] == "perdi":
                            sql = 'UPDATE juegos SET ganador = "%s" WHERE jugador1 = "%s" AND jugador2 = "%s"' % (str(self.a2), str(self.a1), str(self.a2))
                            print("Fin del juego, gana %s" % str(self.a2))
                            mensaje = "['fin_juego','ganador']"
                            self.p2.send(mensaje.encode())
                            #mensaje = "['fin_juego','perdedor']"
                            #self.p1.send(mensaje.encode())
                        else:
                            sql = 'UPDATE juegos SET ganador = "%s" WHERE jugador1 = "%s" AND jugador2 = "%s"' % (str(self.a1), str(self.a1), str(self.a2))
                            print("Fin del juego, gana %s" % str(self.a1))
                            #mensaje = "['fin_juego','perdedor']"
                            #self.p2.send(mensaje.encode())
                            mensaje = "['fin_juego','ganador']"
                            self.p1.send(mensaje.encode())
                        try:
                            conexion, cursor = self.conexion_base_datos()
                            cursor.execute(sql)
                            conexion.commit()
                        except Exception as e:
                            print(e)
                except:
                    pass
            except ValueError as e:
                print(e)
                break
        try:
            self.p1.close()
        except:
            pass
        try:
            self.p2.close()
        except:
            pass
        print('sockets cerrados')

    def conexion_base_datos(self):
        conexion = mysql.connector.connect(user="root", password="", host="localhost",
                                           database="tetris")
        cursor = conexion.cursor()
        return (conexion, cursor)
def main():
    servidor = Servidor()

if __name__ == '__main__':
    main()
